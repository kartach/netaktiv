#
#<?php die('Forbidden.'); ?>
#Date: 2016-11-24 10:10:34 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2016-11-24T10:10:34+00:00	INFO 127.0.0.1	joomlafailure	Empty password not allowed.
2016-12-27T10:29:33+00:00	INFO 127.0.0.1	joomlafailure	Empty password not allowed.
2016-12-27T10:37:27+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-12-27T13:21:02+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2017-02-01T10:43:09+00:00	INFO 192.168.9.155	sloginfailure	Empty password not allowed.
2017-02-01T14:45:33+00:00	INFO 127.0.0.1	sloginfailure	Empty password not allowed.
2017-02-13T10:01:43+00:00	INFO 127.0.0.1	sloginfailure	Empty password not allowed.
